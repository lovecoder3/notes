export default function BlogLayout({ children }) {
//   throw new Error("Error occurred in Blog Layout");

  return (
    <div>
      <p>This is a Blog ID page.</p>
      {children}
    </div>
  );
}
